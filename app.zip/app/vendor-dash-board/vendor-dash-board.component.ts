import { Component, OnInit } from '@angular/core';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-vendor-dash-board',
  templateUrl: './vendor-dash-board.component.html',
  styleUrls: ['./vendor-dash-board.component.css']
})
export class VendorDashBoardComponent implements OnInit {

  vendor : Vendor;
  user : string;
  constructor(private _vendorSerivce : VendorService) {
    this.user = localStorage.getItem("vendorUser")
    this._vendorSerivce.searchByVendorUserName(this.user).subscribe(x => {
      this.vendor=x;
      localStorage.setItem("cid",x.venId.toString())
    })
   }

  ngOnInit(): void {
  }

}
