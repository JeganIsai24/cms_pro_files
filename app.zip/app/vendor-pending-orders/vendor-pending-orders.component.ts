import { Component, OnInit } from '@angular/core';
import { Orders } from '../orders';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-vendor-pending-orders',
  templateUrl: './vendor-pending-orders.component.html',
  styleUrls: ['./vendor-pending-orders.component.css']
})
export class VendorPendingOrdersComponent implements OnInit {

  orders : Orders[];
  cid : number;
  constructor(private _vendorService : VendorService) {
    this.cid=parseInt(localStorage.getItem("cid"));
    this._vendorService.showVendorPendingOrders(this.cid).subscribe(x => {
        this.orders=x;
    })
   }

  ngOnInit(): void {
  }

}
