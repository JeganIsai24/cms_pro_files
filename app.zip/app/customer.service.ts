import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { Orders } from './orders';
import { Wallet } from './wallet';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  public showCustomerPendingOrders(cid : number) : Observable<Orders[]> {
    return this._http.get<Orders[]>("http://localhost:1234/customerOrders/"+cid)
  }
  

  placeOrder(orderDetails : Orders){
    return this._http.post("http://localhost:1234/placeOrder",orderDetails)
  }

  public showCustomerOrders(cid : number) : Observable<Orders[]> {
    return this._http.get<Orders[]>("http://localhost:1234/customerPendingOrders/"+cid)
  }

  public showCustomerWallet(cid : number) : Observable<Wallet[]> {
    return this._http.get<Wallet[]>("http://localhost:1234/showCustomerWallet/"+cid);
  }

  public showCustomer() : Observable<Customer[]> {
    return this._http.get<Customer[]>("http://localhost:1234/showCustomer")

  }
  public searchByCustomerUserName(user : string) : Observable<Customer> {
    return this._http.get<Customer>("http://localhost:1234/searchBycustomerUsername/"+user)
  }
  public customerAuthenticate(user : string, pwd:string) : Observable<string> {
    return this._http.get<string>("http://localhost:1234/custAuthenticate/"+user+ "/" +pwd)

  }
  constructor(private _http : HttpClient) { }
}
