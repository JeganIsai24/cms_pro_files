import { Component, OnInit } from '@angular/core';
import { Orders } from '../orders';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-vendor-orders',
  templateUrl: './vendor-orders.component.html',
  styleUrls: ['./vendor-orders.component.css']
})
export class VendorOrdersComponent implements OnInit {

  orders : Orders[];
  cid : number;
  constructor(private _vendorService : VendorService) {
    this.cid = parseInt(localStorage.getItem("cid"));
   
    this._vendorService.showVendorOrders(this.cid).subscribe(x => {
      this.orders=x;
    })
   }

  ngOnInit(): void {
  }

}
