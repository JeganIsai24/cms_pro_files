import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {

  userName : string;
  passCode : string;

  login() {
  
    this._customerService.customerAuthenticate(this.userName,this.passCode).subscribe(x =>{
      if (x=="1") {
        localStorage.setItem("customerUser",this.userName);
        this._router.navigate(['/customerDashBoard']);
      }
      else{
        alert("invalid credentials")
      }
    })
    // if (this.userName=="Jegan" && this.passCode=="Jegan") {
    //   this._router.navigate(['/customerDashBoard']);
    // }
  }
  constructor(private _router : Router, private _customerService : CustomerService) { 
   
  }

  ngOnInit(): void {
  }

}
