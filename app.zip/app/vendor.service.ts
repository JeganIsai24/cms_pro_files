import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';import { Orders } from './orders';
import { Vendor } from './vendor';

@Injectable({
  providedIn: 'root'
})
export class VendorService {


  public showVendorPendingOrders(cid : number) : Observable<Orders[]> {
    return this._http.get<Orders[]>("http://localhost:1234/vendorPendingOrders/"+cid)
  }

  public acceptRejectOrder(oid : number, vid: number, status: string){
    return this._http.post("http://localhost:1234/acceptOrRejectOrder/"+oid+"/"+ vid+"/YES"+status,null)
  }

  public showVendorOrders(vid : number) : Observable<Orders[]> {
    return this._http.get<Orders[]>("http://localhost:1234/vendorOrders/"+vid)
  }

  public vendorAuthenticate(user : string, pwd:string) : Observable<string> {
    return this._http.get<string>("http://localhost:1234/vendorAuthenticate/"+user+ "/" +pwd)

  }
  public showVendor() : Observable<Vendor[]> {
    return this._http.get<Vendor[]>("http://localhost:1234/showVendor")
  }

  public searchByVendorUserName(user : string) : Observable<Vendor> {
    return this._http.get<Vendor>("http://localhost:1234/searchByVendorUsername/"+user)
  }
  constructor(private _http : HttpClient) { }
}
