import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-wallet',
  templateUrl: './customer-wallet.component.html',
  styleUrls: ['./customer-wallet.component.css']
})
export class CustomerWalletComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
